class Node:
    def  __init__(self,data):
        self.data=data
        self.next=None
class  Linkedlist:
    def __init__(self):
        self.head=None
    def insert_at_end(self,data):
        new=Node(data)
        if self.head is None:
            self.head=new
            return
        t=self.head
        while t.next:
            t=t.next
        t.next=new
    def merge(self,l1,l2):
        dummy=Node(0)
        t=dummy
        while l1 and l2:
            if l1.data<l2.data:
                t.next=l1
                l1=l1.next
            else:
                t.next=l2
                l2=l2.next
            t=t.next
        t.next=l1 or l2
        return dummy.next
l=Linkedlist()
l.insert_at_end(3)
l.insert_at_end(5)
l.insert_at_end(8)
l.insert_at_end(9)
l.insert_at_end(10)
L=Linkedlist()
L.insert_at_end(3)
L.insert_at_end(6)
L.insert_at_end(67)
L.insert_at_end(89)
L.insert_at_end(90)


