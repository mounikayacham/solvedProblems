def subarrsum(arr,k):
    pre={}
    cs=0
    res=0
    for i in arr:
        cs+=i
        if cs==k:
            res+=1
        if cs-k in pre:
            res+=pre[cs-k]

        pre[cs]=pre.get(cs,0)+1
        
    return res
arr=[1,3,42,4,5,6,7,8,9]
k=15
print(subarrsum(arr,k))
            
