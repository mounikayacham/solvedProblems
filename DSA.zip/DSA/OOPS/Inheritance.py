'''class Ab:
    def __init__(self,k):
        self.k=k
    def hi(self,k):
        return f'k = {k}'
        
class c(Ab):
    def __init__(self,b):
        self.b=b
    def he(self,b):
        return f'b = {b}'

a=c(5)
print(a.he(5))
print(a.hi(7))
class Student:
    def greet(self):
        print('hello python')
class b:
    def sat(self):
        print('parent')
class kiets(Student,b):
    pass
obj=kiets()
obj.greet()
obj.sat()

#Single inheritance and method Overriding
class Ab:
    def parent(self):
        print("This is a parent")
class C(Ab):
    def parents(self):
        print(" This is a parent from the child")
obj=C()
obj.parent()

#multilevel inheritance
class collage:
    def clg(self):
        print('This is a collage')
class Btech(collage):
    def eng(self):
        print('this is a engineering cource')
class Aid(Btech):
    def Class(self):
        print("This is my class")

c=Aid()
c.clg()
c.eng()
c.Class()
#multiple
#method overloading

class Father:
    def greet(self):
        print('Hello from the Father')
class Mother:
    def greet(self):
        print('Hello from the mother')       
class child(Father,Mother):
    pass

c=child()
c.greet()

class collage:
    def clg(self):
        print('This is a collage')
class Btech(collage):
    def eng(self):
        print('this is a engineering cource')
class Aid(collage):
    def Class(self):
        print("This is my class")
class Sec(Btech,Aid):
    def hi(self):
        print("This is my class")

b=Aid()
p=Sec()
p.clg()
b.Class()
b.clg()
'''
class Ab:
    def parent(self):
        print("This is a parent")
class C(Ab):
    
    def parent(self):
        super().parent()
        print("This is a parent from the child")
obj=C()
obj.parent()
