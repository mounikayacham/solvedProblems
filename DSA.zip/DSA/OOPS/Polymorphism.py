# One class /method /function/operator used in multiple ways
print(2+3)
print('2'+'3')
