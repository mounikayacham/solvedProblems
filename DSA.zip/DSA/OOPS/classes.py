~'''class car:
    def __init__(self,color,Type):
        self.color=color
        self.Type=Type
    def add(self,a,b):
        self.a=a
        self.b=b
        return self.a+self.b
    def multiply(self,a,b):
        self.a=a
        self.b=b
        return self.a**self.b
    def speces(self,speed,weight):
        print(f'{speed} km/h,{weight} kg')
Car=car('red','Sedan')
print(Car.color)
print(Car.Type)
Car2=car('suv','black')
print(Car2.color)
print(Car2.Type)
print(Car2.add(2,3))
print(Car2.multiply(2,9))
print(Car2.speces(34,678))

n=int(input())
for i in range(1,n+1):
    print("* "*i)
s=input()
res=''
for i in s:
    if i.isalnum():
        res+=i   
print(res)
import re
s=input()
n=re^[0-9][a-z][A-Z]
res=''
for i in s:
    if i in n:
        res+=i
print(res)'''


arr=[1,2,3,4,56,7,8,45]
l=float('-inf')
s=float('-inf')
'''for i in arr:
    if i>l:
        l=i
for j in arr:
    if j<l and j>s:
        s=j'''
for i in arr:
    if i>l:
        l,s=i,l
    elif l>i>s:
        s=i        
print(s)



