'''n,k=input().split()
n=int(n)
k=int(k)
try:
    print(n//k)
except  ZeroDivisionError:
    print('error : Zero division error')
finally:
    print("completed")

'''
try:
    a=20/0
except ZeroDivisionError:
    print('error ')