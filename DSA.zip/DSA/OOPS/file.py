f=open('hi.txt',"r")
print(f.read())
with open('hi.txt',"w") as f:
    f.write("hi my name is preethi I am studying btech final year")
with open('hi.txt',"a") as f:
    f.write("\nhi my name is  Nandhini I am studying btech final year")
with open('hi.txt',"r+") as f:
    print(f.read())
    f.seek(0)
    f.write("write Something Here")
with open('hi.txt',"w+") as f:
    f.write("write Something Here")
    f.seek(0)
    print(f.read())
    


