def sum_even_digits(n):
    if n == 0:
        return 0
    return (n%10 if n%2==0 else 0) + sum_even_digits(n//10)
n=int(input('enter input'))
print(sum_even_digits(n))
