from collections import deque
class Node:
    def __init__(self,data):
        self.data=data
        self.left=None
        self.right=None
class Tree:
    def  __init__(self):
        self.root=None
    def insert(self,data):
        new=Node(data)
        cur=self.root
        if self.root is None:
            self.root=new
            return
        while True:
            if data<new.data:
                if cur.left:
                    cur=cur.left
                else:
                    cur.left=new
                    return
            else:
                if cur.right:
                    cur=cur.right
                else:
                    cur.right=new
                    return
    def search(self, data):
        current = self.root
        while current:
            if current.data == data:
                return f'\nTrue: {data} is in the tree'
            elif data < current.data:
                current = current.right
            else:
                current = current.left
        return f'\nFalse: {data} is not in the tree'

    def inorder(self,node):#Inorder and preorder and pst order are he examples for the dfs
        if node:
            self.inorder(node.left)
            print(node.data,end=' ')
            self.inorder(node.right)
    def preorder(self,node):
        if node:
            print(node.data,end=' ')
            self.preorder(node.left)
            self.preorder(node.right)
    def postorder(self,node):
        if node:
            self.postorder(node.left)
            self.postorder(node.right)
            print(node.data,end=' ')
    def min_num(self):
        cur=self.root
        if not self.root:
            return None
        while cur.left:
            cur=cur.left
        return cur.data
    def Max_num(self):
        cur=self.root
        while cur.right:
            cur=cur.right
        return cur.data
    def height(self,node):
        if not node:
            return -1
        return 1+max(self.height(node.left),self.height(node.right))
    def bfs(self,root):
        if not self.root:
            return
        queue = deque([root])
        while queue:
            node = queue.popleft()
            print(node.data, end=' ')
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)

                
t=Tree()
t.insert(78)
t.insert(90)
t.insert(34)
t.insert(23)
t.insert(12)
t.insert(45)
t.insert(66)
t.insert(15)
t.insert(80)
print("InOrder")
t.inorder(t.root)
print("\nPreOrder")
t.preorder(t.root)
print("\nPostOrder")
t.postorder(t.root)
print(t.search(54))
print(t.min_num())
print(t.Max_num())
print(t.height(t.root))
t.bfs(t.root)
