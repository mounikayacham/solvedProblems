def toggle_binary(binary):
    return ''.join(['1' if bit == '0' else '0' for bit in binary])

def play_game(arr, rahul_ab, rupesh_ab, k):
    rahul_a, rahul_b = rahul_ab.split()
    rupesh_a, rupesh_b = rupesh_ab.split()
    
    while arr:
        max_index = arr.index(max(arr))
        selected_values = arr[max(0, max_index - k): min(len(arr), max_index + k + 1)]
        del arr[max(0, max_index - k): min(len(arr), max_index + k + 1)]

        if arr:
            if arr[-1] % 2 == 0:
                rupesh_a, rupesh_b = toggle_binary(rupesh_a), toggle_binary(rupesh_b)
            else:
                rahul_a, rahul_b = toggle_binary(rahul_a), toggle_binary(rahul_b)
        
    rahul_sum = int(rahul_a, 2) + int(rahul_b, 2)
    rupesh_sum = int(rupesh_a, 2) + int(rupesh_b, 2)

    if rahul_sum > rupesh_sum:
        return "Rahul"
    elif rupesh_sum > rahul_sum:
        return "Rupesh"
    else:
        return "Both"

# Input reading
arr = list(map(int, input().split()))
rahul_ab = input().strip()
rupesh_ab = input().strip()
k = int(input())

# Output the result
result = play_game(arr, rahul_ab, rupesh_ab, k)
print(result)
