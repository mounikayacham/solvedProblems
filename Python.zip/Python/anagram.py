p='amma'
p1='mama'
fre={}
def anagram(p,p1):
    for i in p:
        fre[i]=fre.get(i,0)+1
    print(fre)
    for i in p1:
        fre[i]=fre.get(i,0)-1
    print(fre)
    for k in fre.values():
        if k!=0:
            return False
    return True
print(anagram(p,p1))
    
        

