def maximize_points(chocolates, initial_chocolates):
    n = len(chocolates)
    dp = [0] * (initial_chocolates + 1)

    for i in range(n):
        for j in range(initial_chocolates, chocolates[i] - 1, -1):
            dp[j] = max(dp[j], dp[j - chocolates[i]] +2)

    return dp[initial_chocolates]

# Input reading
bag_chocolates = list(map(int, input().split()))
initial_chocolates = int(input())

# Output the result
result = maximize_points(bag_chocolates, initial_chocolates)
print(result)
