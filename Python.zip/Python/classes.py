class Name:
    def __init__(self,name,rollno):
        self.name=name
        self.rollno=rollno
    def display(self):
        print(self.name)
        print(self.rollno)
    def employee(self,name,salary,company,distance):
        self.name=name
        self.salary=salary
        self.comapany=company
        self.distance=distance
        print(self.name,self.salary,self.comapany,self.distance)
class Teacher(Name):
    def __int__(self,name,subject):
        super().__init__(name,rollno)
        self.subject=subject
    def displaay(self,salary,place):
        self.salary=salary
        self.place=place
        print(self.name,self.salary,self.place)
obj=Name('mounika',4528)
obj.display()
obj.employee('mounika',234056,'GOOGLE','Narsapoor')
obj1=Teacher('nandini',45786)
obj1.displaay(768382,'Gudivada')
obj1.employee('Tejasri',1347727,'MICROSOFT','Narsipatnam')
obj1.displaay(6474284,'guntoor')



