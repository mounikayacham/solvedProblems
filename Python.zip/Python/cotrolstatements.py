'''n=int(input("Enter the the number"))
dp=[0]*(n+1)
if n%3==0 and n%5==0:
    print("divisible by both the numbers 3 and 5")
print(dp)
dp[0]=0
dp[1]=1
for i in range(2,n+1):
    dp[i]=dp[i-1]+dp[i-2]
print(dp)
def Climb(n):
    dp=[0]*(n+1)
    dp[0]=dp[1]=1
    for i in range(2,n+1):
       dp[i]=dp[i-1]+dp[i-2]
    return dp,dp[n]
print(Climb(n))'''
'''def mincost(k):
    n=len(k)
    dp=[0]*(n)
    dp[0]=k[0]
    dp[1]=k[1]
    for i in range(2,n):
        dp[i]=k[i]+min(dp[i-1],dp[i-2])
    return min(dp[-1],dp[-2])
k=list(map(int,input().split()))
print(mincost(k))
 '''

'''
def LongestCommonSubsequence(s1,s2):
    n,m=len(s1),len(s2)
    dp=[[0]*(m+1) for _ in range(n+1)]
    for i in range(1,n+1):
        for j in range(1,m+1):
            if s1[i-1]==s2[j-1]:
                dp[i][j]=1+dp[i-1][j-1]
            else:
                dp[i][j]=max(dp[i-1][j],dp[i][j-1])
    return dp[n][m],dp
                                
s1,s2=map(str,input().split())
print(LongestCommonSubsequence(s1,s2))
'''          
'''      

a,b=map(int,input().split())
if a<b:
    print('b is bigger than the a')
else:
    print('a is bigger than the b')

age=int(input('Enter your age :'))
if age>18:
    print(' You are eligible')
else:
    print(' You are Not eligible')

v='aeiouAEIOU'
s=input('enter the String')
for i in s:
    if i in v:
        print('True')
        break
else:
    print('False')
    

year=int(input('enter the year'))
if (year%4==0 and year%100!=0) or year%400:
    print("True")
else:
    print('False')

password='hi'
k=input('enter the password')
if password==k:
    print('valid')
else:
    print('Not Valid')
        
'''
def coin(arr,k):
    dp=[float('inf')*(k+1)]
    dp[0]=0
    for i in  range(len(arr)):
        for j in range(i,k+1):
            dp[j]=min(dp[j],dp[j-i]+1)
    return dp[k] if dp[k]!=float('inf') else -1
arr=list(map(int,input().split()))
k=int(input())
print(coin(arr,k))











