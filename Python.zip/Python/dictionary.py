d={'name':'abc','rno':1234,'dept':'cse','course':'B.tech'}
print(d)
print(d['name'])
print(d['rno'])
print(d['dept'])
print(d['course'])
d['course']='m.tech'
print('after changing the course: ',d)
del d['dept']
p=d.copy()
print('After Deleting the the department :',d)
#del p  #del d error will comes
print("After deleting the dictionary by using the dle keyword :",d)
#d.clear()
print("After deleting the dictionary by using the dle keyword :",d)
print("all items in the dictionary :\n",p.items())#in list
print("all values in the dictionary:\n",p.values())#in list
k=p.values()
for i in k:
    print(i,end=" ")
print("all keys in the dictionary\n",p.keys())
#update method
d.update({'branch':'aid','college':'kiet-w'})
print('Dictionary after updating many : \n',d)
d.update({'section':'A'})
print('Dictionary after updating one element : \n',d)
print(d.pop('rno'))
d.pop('name')#it is not printed if we want to prnt it need to print in the print function
print(d.popitem())#recently inserted element
print(d.get('course'))
for i in d:
    print(d[i])
print(d.fromkeys(('a','b','c'),0))
