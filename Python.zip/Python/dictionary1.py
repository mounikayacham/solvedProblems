Python 3.12.2 (tags/v3.12.2:6abddd9, Feb  6 2024, 21:26:36) [MSC v.1937 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> d={'name':'abc','rno':1234,'dept':'cse','course':'B.tech'}
... 
>>> print(d)
{'name': 'abc', 'rno': 1234, 'dept': 'cse', 'course': 'B.tech'}
>>> d['course']='M.tech'
>>> print(d)
{'name': 'abc', 'rno': 1234, 'dept': 'cse', 'course': 'M.tech'}
>>> #copy()
