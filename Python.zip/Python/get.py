'''from collections import Counter
s=' yachammounika'
f={}
for c in s:
    f[c]=f.get(c,0)+1
print(f)
fre=Counter(s)
print(fre)
'''
arr=list(map(int,input().split()))
res=0
k=0
for i in arr:
    res^=i
print(res)
print(5^2)
