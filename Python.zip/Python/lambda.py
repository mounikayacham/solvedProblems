'''names=['anu','vijju','gowtham']
u=list(map(str.upper,names))
print(u)
'''
x=10
def show():
    print(x)
show()
print(x)
    
