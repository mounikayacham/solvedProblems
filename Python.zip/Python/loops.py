'''for i in range(5):
    if i==4:
        break
    if i==2:
        continue
    print(i)'''
matrix = [
  [1, 2, 3],
  [4, 5, 6],
  [7, 8, 9]
]
'''for i in range(len(matrix)):
    for j in range(len(matrix[0])):
        print(matrix[i][j],end=' ')
    print()
for i in matrix:
    for j in i:
        print(j,end=' ')
    
 '''

n=len(matrix)
m=len(matrix[0])
'''
t=[]
for i in range(n):
    row=[]
    for j in range(m):
        row.append(matrix[j][i])
    t.append(row)
print(t)
        
'''
'''
#search in matrix in bruetforce
t=10
f=False
for i in range(n):
    for j in range(m):
        if matrix[j][i]==t:
            print('found at',i,j)
            f=True
            break
if f==False:
    print('not found')
'''
'''
for i in range(1,101):
    if i%2==0:
        print(i,end=' ')
    else:
        continue
'''
'''
top=0
bottom=2
left=0
right=2

while top<=bottom and left<=right:
    for i in range(left,right+1):
        print(matrix[top][i],end=' ')
    top+=1
    for i in range(top,bottom+1):
        print(matrix[i][right],end=' ')
    right-=1
    if top<=bottom:
        for i in range(right,left-1,-1):
            print(matrix[bottom][i],end=' ')
        bottom-=1
    if left<=right:
        for i in range(bottom,top-1,-1):
            print(matrix[i][left],end=' ')
        left+=1

'''


'''
#column sum
for i in range(n):
    s=0
    for j in range(m):
        s+=matrix[j][i]
    print('column',i,'sum:',s)
#row sum
for i in range(n):
    s=0
    for j in range(m):
        s+=matrix[i][j]
    print('row',i,'sum:',s)
for i in range(1,11):
    for j in range(1,21):
        print(i*j,end=' ')
    print()
'''

matrix1= [
    [1, 2, 3],
    [2, 4, 5],
    [3, 5, 6]
]

m=0
a=0
for i in range(n):
    m+=matrix[i][i]
    a+=matrix[i][n-i-1]
print('mainDiaginal sum :',m)
print('Anti Diagonal sum :',a)

s=True
for i in range(n):
    for j in range(n):
        if matrix1[i][j]!=matrix1[j][i]:
            s=False
            break
print(s)

for i in range(n):
    for j in range(i+1,n):
        matrix[i][j],matrix[j][i]=matrix[j][i],matrix[i][j]
for i in matrix:
    i.reverse()
print(matrix)


i=0
while i<10:
    i+=1
    if i==7:
        continue
    print(i)
    





    
        
