def check_valid(grid):
    for i in range(9):
        for j in range(9):
            if grid[i][j] != 0:
                for x in range(9):
                    if x != i and grid[x][j] == grid[i][j]:
                        return False
                    if x != j and grid[i][x] == grid[i][j]:
                        return False
                row_start, col_start = 3 * (i // 3), 3 * (j // 3)
                for x in range(row_start, row_start + 3):
                    for y in range(col_start, col_start + 3):
                        if (x != i or y != j) and grid[x][y] == grid[i][j]:
                            return False
    return True

def solve(grid, numbers, k):
    positions_to_change = []
    for i in range(9):
        for j in range(9):
            if grid[i][j] == 0:
                original_value = grid[i][j]
                for num in numbers:
                    grid[i][j] = num
                    if check_valid(grid):
                        positions_to_change.append((i, j))
                        break
                grid[i][j] = original_value
    
    if len(positions_to_change) <= k:
        return positions_to_change
    else:
        return "Impossible"

# Input reading
grid = []
for _ in range(9):
    row = list(map(int, input().split()))
    grid.append(row)

numbers = list(map(int, input().split()))
k = int(input())

# Output the result
result = solve(grid, numbers, k)

if result == "Impossible":
    print(result)
else:
    for pos in result:
        print(pos[0], pos[1])
