'''a=int(input())
b=int(input())
c=int(input())
if a>b and a>c:
    print(a,"is big number")
elif b>c:
    print(b,"is big number")
else:
    print(c,"is big number")'''

'''
a,b= map(int,input().split())
s=a+b
p=a*b
if s<0 or p<0:
     print('yes')
else:
    print('no')
'''

'''a,b,c=map(int,input().split())
if ((a+b)>c or (b+c)>a or (c+a)>b ):
    print ("true")
else:
    print("False")'''

'''a,b=map(str,input().split())
if a[-3:]==a[-3:]:
    print("True")
else:
    print("False")'''

'''length,breadth=map(int,input().split())
area=length*breadth
perimeter=2*(length+breadth)
if area<=perimeter:
    print("True")
else:
    print("False")'''
'''
a,b=map(int,input().split())
if (a<60 or b<60 )and (a>70 or b>70):
    print("True")
else:
    print("False")
'''
'''
a,b,c=map(int,input().split())
if (a+b)>90 and (b+c)>90 and (c+a)>90:
    print("True")
else:
    print("False")
    
'''
n=int(input())
if n>50 and n<200:
    print("True")
else:
    print("False")
while n>0:
    k=n%10
    n=n//10
print(k)
if k==7:
    print("TRue")
else:
    print("False")




















    

    
    
