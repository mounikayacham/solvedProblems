for i in range(1,11):
    print(i,end=' ')
for j in range(11):
    print(j,end=' ')
for  j in range(1,11,2):
    print(j,end=' ')

n=[10,20,30,40,50]
t=0
for i in n:
    t+=i
    if t>100:
        break
print(t)
