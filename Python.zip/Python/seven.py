def seven_segment_display(digit, side):
    segments = {
        '0': [' -- ', '|  |', '|  |', '|  |', ' -- '],
        '1': ['    ', '   |', '   |', '   |', '    '],
        '2': [' -- ', '   |', ' -- ', '|   ', ' -- '],
        '3': [' -- ', '   |', ' -- ', '   |', ' -- '],
        '4': ['    ', '|  |', ' -- ', '   |', '    '],
        '5': [' -- ', '|   ', ' -- ', '   |', ' -- '],
        '6': [' -- ', '|   ', ' -- ', '|  |', ' -- '],
        '7': [' -- ', '   |', '   |', '   |', '    '],
        '8': [' -- ', '|  |', ' -- ', '|  |', ' -- '],
        '9': [' -- ', '|  |', ' -- ', '   |', ' -- '],
    }

    mirror_directions = {'U': 0, 'L': 1, 'D': 2, 'R': 3, 'S': 4}

    image = segments[digit][mirror_directions[side]]
    return image

# Input reading
digits = input().strip()
side = input().strip()

# Output the result
output = ""
for d, s in zip(digits, side):
    output += seven_segment_display(d, s)

print(output)
