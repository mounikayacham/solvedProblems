def max_common_subsequence_length(s1, s2, k):
    m, n = len(s1), len(s2)
    dp = [[0] * (n + 1) for _ in range(m + 1)]

    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if abs(ord(s1[i - 1]) - ord(s2[j - 1])) <= k:
                dp[i][j] = dp[i - 1][j - 1] + 1
            dp[i][j] = max(dp[i][j], dp[i - 1][j], dp[i][j - 1])

    return dp[m][n]

# Input reading
s1 = input().strip()
s2 = input().strip()
k = int(input())

# Output the result
result = max_common_subsequence_length(s1, s2, k)
print(result)
