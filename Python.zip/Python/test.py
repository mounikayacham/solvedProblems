'''n=int(input())
n1=int(input())
s=0
for i in range(n,n1+1):
    s+=i**3
print(s)'''

'''#2.
n=int(input())
s=0
for i in range(1,n+1):
    if i<=50:
        s+=3
    elif i<=100:
        s+=5
    elif i<=200:
        s+=6
    elif i<=250:
        s+=8
    else:
        s+=10
print(s)
    '''
'''
n=int(input())
r=0
p=n
while n>0:
    k=n%10
    r+=k**3
    n=n//10
print(r)
if p==r:
    print("True")
else:
    print("False")
    
'''
