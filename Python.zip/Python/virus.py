def min_data_to_trap_virus(M, N, containers, virus_location, dummy_location):
    def get_neighbours(x, y, M, N):
        neighbours = []
        for i in range(max(0, x - 1), min(M, x + 2)):
            for j in range(max(0, y - 1), min(N, y + 2)):
                if i != x or j != y:
                    neighbours.append((i, j))
        return neighbours

    def is_valid(x, y, M, N):
        return 0 <= x < M and 0 <= y < N

    def virus_moves_to(virus_location, target, containers):
        x, y = virus_location
        target_x, target_y = target
        virus_neighbours = get_neighbours(x, y, M, N)
        max_neighbour_data = max(containers[nx][ny] for nx, ny in virus_neighbours if is_valid(nx, ny, M, N))
        return containers[target_x][target_y] == max_neighbour_data

    def fudge_data(x, y, data_required, containers):
        data_fudged = 0
        while data_fudged < data_required:
            containers[x][y] += 1
            data_fudged += 1

    virus_x, virus_y = virus_location
    dummy_x, dummy_y = dummy_location

    min_data_required = 0

    while not virus_moves_to((virus_x, virus_y), (dummy_x, dummy_y), containers):
        max_neighbour_data = max(
            containers[nx][ny] for nx, ny in get_neighbours(virus_x, virus_y, M, N) if is_valid(nx, ny, M, N)
        )
        min_data_required += max_neighbour_data + 1
        fudge_data(virus_x, virus_y, max_neighbour_data + 1, containers)

    return min_data_required

# Input reading
M, N = map(int, input().split())
containers = [list(map(int, input().split())) for _ in range(M)]
virus_location = tuple(map(int, input().split()))
dummy_location = tuple(map(int, input().split()))

# Output the result
result = min_data_to_trap_virus(M, N, containers, virus_location, dummy_location)
print(result)
